import java.util.Stack;

public class Cau3 {
    public static int calculate(String[] expression) {
        // code here
    }

    public static void main(String args[]){
		System.out.println(calculate(new String[]{"31", "12", "+"}));
	}
}